=== Idolcorp ===

Requires at least: 4.5
Tested up to: 4.5.2

License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Idolcorp WordPress Theme, Copyright 2016 ThemeIdol
Idolcorp is distributed under the terms of the GNU GPL v3


== Installation ==
	
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== TRANSLATIONS ==
If you've translated this theme into your language, feel free to send the translation over to themeidol@gmail.com
and we will include it within the theme from next version update.

== How to use featured Post Slider? ==
To use the slider.
* Create Post Category for Slider of your choice , let say "Slider" Category 
* Create Posts, Add featured image to the Post with the selection of "Slider" as category
* Select the respective slider category from Homepage Settings -> Slider Settings in the customizer.
* Featured Slider will show with featured images (iff preseent), Title and excerpt of the respected added post in Homepage Template.


------------------------------------------

JS Files 
    bxSlider: WTFPL and MIT license
    https://github.com/stevenwanderski/bxslider-4

    jquery.nicescroll
    copyright 2013-11-13 InuYaksa*2013
    licensed under the MIT
    http://areaaperta.com/nicescroll
    https://github.com/inuyaksa/jquery.nicescroll
    
    respond.js
    Copyright 2011: Scott Jehl, scottjehl.com
    Licensed under the MIT license.
    https://github.com/scottjehl/Respond
   
    html5shiv
    Copyright (c) 2014 Alexander Farkas (aFarkas).
    Licensed under the MIT license.
    https://github.com/aFarkas/html5shiv

CSS Files   
    Bootstrap v3.3.5 (http://getbootstrap.com)
    Copyright 2011-2015 Twitter, Inc.
    Licensed under the MIT license
    http://getbootstrap.com/

    Font Awesome 4.4.0 by @davegandy - http://fontawesome.io - @fontawesome
    License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)

 Image Files
    Banner images
   	https://pixabay.com/en/desk-computer-modern-keyboard-1140699/
   	https://pixabay.com/en/office-tax-business-finance-620822/
   best-theme.png
   	https://unsplash.com/photos/ZkHvTmG967c    
   blog-full.png  
   	https://unsplash.com/photos/ZkHvTmG967c
   call_to_action-1.jpg
        https://pixabay.com/en/wordpress-create-free-website-build-1007077/   
   call_to_action-2.jpg
       https://pixabay.com/en/man-jumping-happy-excited-run-21136/

== Credits ==
