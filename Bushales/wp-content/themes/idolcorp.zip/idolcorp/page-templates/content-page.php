<?php
/**
 * The template used for displaying page content
 *
 *
 * @package Idolcorp
 * @since Idolcorp 1.0
 */
wp_reset_postdata();
?>                
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  
  <?php idolcorp_blog_content_without_search();?>
  
  <footer class="entry-footer">
    <?php edit_post_link( esc_html__( 'Edit', 'idolcorp' ), '<div class="fa-pencil-square-o edit-link">', '</div>' ); ?>
  </footer><!-- .entry-footer -->
</article>