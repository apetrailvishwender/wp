<?php
/**
 * Customer new account email
 *
 * @author 		A3rev
 * @package 	woocommerce-email-inquiry-ultimate/templates/emails
 * @version     1.6.4
 */

?>

<?php _e('Please Upgrade to WooCommerce Quotes and Orders plugin', 'woocommerce-email-inquiry-cart-options' );?>
