<?php
/**
 * Send quote email
 *
 * @author 		A3rev
 * @package 	woocommerce-email-inquiry-ultimate/templates/emails
 * @version     2.1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>

<?php _e('Please Upgrade to WooCommerce Quotes and Orders plugin', 'woocommerce-email-inquiry-cart-options' );?>